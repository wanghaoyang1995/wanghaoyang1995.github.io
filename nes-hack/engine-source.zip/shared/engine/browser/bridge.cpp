#include "pch.h"
#include <emscripten/emscripten.h>
#include "Shared/Emulator.h"
#include "Shared/EmuSettings.h"
#include "Shared/KeyManager.h"
#include "Shared/MessageManager.h"
#include "Shared/RenderedFrame.h"
#include "Shared/Video/VideoRenderer.h"
#include "Shared/Audio/SoundMixer.h"
#include "Shared/Interfaces/IKeyManager.h"
#include "Shared/Interfaces/IInputProvider.h"
#include "Shared/Interfaces/IRenderingDevice.h"
#include "Shared/Interfaces/IAudioDevice.h"
#include "Debugger/Debugger.h"
#include "Debugger/ScriptManager.h"
#include "NES/NesConsole.h"
#include "NES/NesCpu.h"
#include "NES/Input/NesController.h"
#include "Utilities/FolderUtilities.h"
#include "Utilities/VirtualFile.h"

namespace {
std::unique_ptr<Emulator> emu;
std::vector<uint8_t> rgba;
std::vector<int16_t> pcm;
uint32_t width = 256, height = 240;
int scriptId = -1;
std::string lastError, scriptLog;
// Original desktop defaults from UI/Config/NesConfig.cs. C++ initializes this
// user palette to zero, so a UI-free host must supply it explicitly.
constexpr uint32_t defaultPalette[64] = {
    0xFF666666,0xFF002A88,0xFF1412A7,0xFF3B00A4,0xFF5C007E,0xFF6E0040,0xFF6C0600,0xFF561D00,
    0xFF333500,0xFF0B4800,0xFF005200,0xFF004F08,0xFF00404D,0xFF000000,0xFF000000,0xFF000000,
    0xFFADADAD,0xFF155FD9,0xFF4240FF,0xFF7527FE,0xFFA01ACC,0xFFB71E7B,0xFFB53120,0xFF994E00,
    0xFF6B6D00,0xFF388700,0xFF0C9300,0xFF008F32,0xFF007C8D,0xFF000000,0xFF000000,0xFF000000,
    0xFFFFFEFF,0xFF64B0FF,0xFF9290FF,0xFFC676FF,0xFFF36AFF,0xFFFE6ECC,0xFFFE8170,0xFFEA9E22,
    0xFFBCBE00,0xFF88D800,0xFF5CE430,0xFF45E082,0xFF48CDDE,0xFF4F4F4F,0xFF000000,0xFF000000,
    0xFFFFFEFF,0xFFC0DFFF,0xFFD3D2FF,0xFFE8C8FF,0xFFFBC2FF,0xFFFEC4EA,0xFFFECCC5,0xFFF7D8A5,
    0xFFE4E594,0xFFCFEF96,0xFFBDF4AB,0xFFB3F3CC,0xFFB5EBF2,0xFFB8B8B8,0xFF000000,0xFF000000
};

class BrowserKeys final : public IKeyManager {
    bool keys[512] = {};
public:
    void RefreshState() override {}
    void UpdateDevices() override {}
    bool IsMouseButtonPressed(MouseButton) override { return false; }
    bool IsKeyPressed(uint16_t code) override { return code < 512 && keys[code]; }
    std::vector<uint16_t> GetPressedKeys() override {
        std::vector<uint16_t> result;
        for(uint16_t i=1;i<512;i++) if(keys[i]) result.push_back(i);
        return result;
    }
    std::string GetKeyName(uint16_t code) override {
        if(code >= 'A' && code <= 'Z') return std::string(1, char(code));
        switch(code) { case 13:return "Enter"; case 32:return "Space";
        case 37:return "Left"; case 38:return "Up"; case 39:return "Right"; case 40:return "Down"; }
        return "";
    }
    uint16_t GetKeyCode(std::string name) override {
        if(name.size()==1) return uint16_t(std::toupper(name[0]));
        if(name=="Enter" || name=="Return") return 13;
        if(name=="Space") return 32;
        if(name=="Left") return 37; if(name=="Up") return 38;
        if(name=="Right") return 39; if(name=="Down") return 40;
        return 0;
    }
    bool SetKeyState(uint16_t code,bool state) override {
        if(code>=512) return false; keys[code]=state; return true;
    }
    void ResetKeyState() override { memset(keys,0,sizeof(keys)); }
    void SetDisabled(bool disabled) override { if(disabled) ResetKeyState(); }
} keys;

// Explicit pads are separate from raw keyboard keys used by Lua. The provider
// runs before InputPolled scripts, so getInput/setInput retain native ordering.
class BrowserPads final : public IInputProvider {
    bool explicitMode = false;
    uint8_t masks[2] = {};
public:
    void Clear() { masks[0]=masks[1]=0; }
    void UseExplicit(bool enabled) {
        if(explicitMode != enabled) Clear();
        explicitMode=enabled;
    }
    bool SetMask(int port,int mask) {
        if(port<0 || port>1 || mask<0 || mask>255) return false;
        masks[port]=uint8_t(mask);
        return true;
    }
    bool SetInput(BaseControlDevice* device) override {
        if(!explicitMode || device->GetControllerType()!=ControllerType::NesController || device->GetPort()>1) return false;
        uint8_t mask=masks[device->GetPort()];
        if(!emu->GetSettings()->GetNesConfig().AllowInvalidInput) {
            if((mask&0x30)==0x30) mask&=~0x30;
            if((mask&0xC0)==0xC0) mask&=~0xC0;
        }
        constexpr uint8_t buttons[8]={NesController::A,NesController::B,NesController::Select,NesController::Start,
            NesController::Up,NesController::Down,NesController::Left,NesController::Right};
        device->ClearState();
        for(uint8_t bit=0;bit<8;bit++) device->SetBitValue(buttons[bit],(mask&(1u<<bit))!=0);
        return true;
    }
} pads;

class BrowserVideo final : public IRenderingDevice {
    std::vector<uint32_t> base;
public:
    BrowserVideo() { emu->GetVideoRenderer()->RegisterRenderingDevice(this); }
    void UpdateFrame(RenderedFrame& frame) override {
        width=frame.Width; height=frame.Height;
        auto pixels=static_cast<uint32_t*>(frame.FrameBuffer);
        base.assign(pixels,pixels+width*height);
    }
    void ClearFrame() override { std::fill(base.begin(),base.end(),0); }
    void Render(RenderSurfaceInfo&, RenderSurfaceInfo& hud) override {
        rgba.resize(width*height*4);
        for(uint32_t y=0;y<height;y++) for(uint32_t x=0;x<width;x++) {
            uint32_t i=y*width+x;
            uint32_t color=i<base.size()?base[i]:0;
            uint32_t r=(color>>16)&255, g=(color>>8)&255, b=color&255;
            if(hud.Buffer && hud.Width && hud.Height) {
                uint32_t over=hud.Buffer[(y*hud.Height/height)*hud.Width+(x*hud.Width/width)];
                uint32_t a=over>>24;
                // Mesen's independent HUD surfaces store premultiplied RGB.
                r=std::min(255u,((over>>16)&255)+r*(255-a)/255);
                g=std::min(255u,((over>>8)&255)+g*(255-a)/255);
                b=std::min(255u,(over&255)+b*(255-a)/255);
            }
            rgba[i*4]=r; rgba[i*4+1]=g; rgba[i*4+2]=b; rgba[i*4+3]=255;
        }
    }
    void Reset() override {}
    void SetFullscreenMode(FullscreenSettings) override {}
};

class BrowserAudio final : public IAudioDevice {
public:
    BrowserAudio() { emu->GetSoundMixer()->RegisterAudioDevice(this); }
    void PlayBuffer(int16_t* samples,uint32_t count,uint32_t,bool) override {
        pcm.insert(pcm.end(),samples,samples+count*2);
    }
    void Stop() override { pcm.clear(); }
    void Pause() override { pcm.clear(); }
    void ProcessEndOfFrame() override {}
    std::string GetAvailableDevices() override { return "browser"; }
    void SetAudioDevice(std::string) override {}
    AudioStatistics GetStatistics() override { return {}; }
};
}

extern "C" {
EMSCRIPTEN_KEEPALIVE int web_init() {
    try {
        FolderUtilities::SetHomeFolder("/mesen");
        FolderUtilities::CreateFolder("/mesen");
        MessageManager::SetOptions(false,true);
        emu=std::make_unique<Emulator>();
        emu->Initialize(false);
        keys.ResetKeyState();pads.UseExplicit(false);pads.Clear();
        KeyManager::SetSettings(emu->GetSettings());
        KeyManager::RegisterKeyManager(&keys);
        auto& settings=*emu->GetSettings();
        auto nes=settings.GetNesConfig();
        std::copy(std::begin(defaultPalette),std::end(defaultPalette),nes.UserPalette);
        nes.EnableHdPacks=false; nes.DisableGameDatabase=true;
        nes.AutoConfigureInput=false; nes.Region=ConsoleRegion::Ntsc;
        nes.RamPowerOnState=RamState::AllZeros;
        nes.Port1.Type=ControllerType::NesController;
        nes.Port2.Type=ControllerType::NesController;
        auto& map=nes.Port1.Keys.Mapping1;
        map.A='X';map.B='Z';map.Up=38;map.Down=40;map.Left=37;map.Right=39;map.Start=13;map.Select=32;
        for(auto& volume:nes.ChannelVolumes) volume=100;
        settings.SetNesConfig(nes);
        auto pref=settings.GetPreferences();
        pref.DisableOsd=true;pref.DisableGameSelectionScreen=true;
        pref.AutoSaveStateDelay=0;pref.RewindBufferSize=0;
        settings.SetPreferences(pref);
        auto audio=settings.GetAudioConfig();
        audio.EnableAudio=true;audio.SampleRate=48000;audio.MasterVolume=100;
        settings.SetAudioConfig(audio);
        emu->SetAudioVideoInitCallback([](){return new BrowserAudio();},[](){return new BrowserVideo();});
        emu->GetVideoRenderer()->SetRendererSize(512,480);
        return 1;
    } catch(const std::exception& e) { lastError=e.what();return 0; }
}
EMSCRIPTEN_KEEPALIVE int web_load_rom(const uint8_t* data,int size) {
    try {
        if(!emu) return 0;
        scriptId=-1;pcm.clear();keys.ResetKeyState();pads.Clear();
        emu->UnregisterInputProvider(&pads);
        // Keep the source in MEMFS: Mesen reopens it for power cycles and hashes.
        { std::ofstream file("/game.nes",std::ios::binary);file.write(reinterpret_cast<const char*>(data),size); }
        bool ok=emu->LoadRom(VirtualFile("/game.nes"),VirtualFile());
        if(ok) emu->RegisterInputProvider(&pads);
        if(!ok) lastError=MessageManager::GetLog();
        return ok?1:0;
    } catch(const std::exception& e) { lastError=e.what();return 0; }
}
EMSCRIPTEN_KEEPALIVE int web_load_script(const char* data,int size) {
    try {
        if(!emu) return -1;
        emu->InitDebugger();
        scriptId=emu->InternalGetDebugger()->GetScriptManager()->LoadScript("game.lua","/",std::string(data,size),scriptId);
        if(scriptId<0) lastError=MessageManager::GetLog();
        return scriptId;
    } catch(const std::exception& e) { lastError=e.what();return -1; }
}
EMSCRIPTEN_KEEPALIVE int web_step(int count) {
    pcm.clear();int done=0;
    try { while(done<count && emu->BrowserStepFrame()) ++done; }
    catch(const std::exception& e) { lastError=e.what();return -1; }
    return done;
}
EMSCRIPTEN_KEEPALIVE void web_key(int code,int down) { keys.SetKeyState(code,down!=0); }
EMSCRIPTEN_KEEPALIVE void web_use_explicit_pads(int enabled) { pads.UseExplicit(enabled!=0); }
EMSCRIPTEN_KEEPALIVE int web_set_pad(int port,int mask) { return pads.SetMask(port,mask)?1:0; }
EMSCRIPTEN_KEEPALIVE void web_clear_keys() { keys.ResetKeyState();pads.Clear(); }
EMSCRIPTEN_KEEPALIVE void web_pause(int pause) { if(pause) emu->Pause();else emu->Resume(); }
EMSCRIPTEN_KEEPALIVE uint8_t* web_pixels() { return rgba.data(); }
EMSCRIPTEN_KEEPALIVE int web_width() { return width; }
EMSCRIPTEN_KEEPALIVE int web_height() { return height; }
EMSCRIPTEN_KEEPALIVE int16_t* web_audio() { return pcm.data(); }
EMSCRIPTEN_KEEPALIVE int web_audio_count() { return pcm.size(); }
EMSCRIPTEN_KEEPALIVE int web_read(int addr) {
    auto nes=emu?dynamic_cast<NesConsole*>(emu->GetConsoleUnsafe()):nullptr;
    return nes?nes->DebugRead(addr&65535):0;
}
EMSCRIPTEN_KEEPALIVE int web_cpu_register(int field) {
    auto nes=emu?dynamic_cast<NesConsole*>(emu->GetConsoleUnsafe()):nullptr;
    if(!nes) return 0;
    const auto& cpu=nes->GetCpu()->GetState();
    switch(field) {
        case 0:return cpu.PC;case 1:return cpu.A;case 2:return cpu.X;
        case 3:return cpu.Y;case 4:return cpu.SP;case 5:return cpu.PS;
        case 6:return static_cast<uint32_t>(cpu.CycleCount);
        case 7:return static_cast<uint32_t>(cpu.CycleCount>>32);
        default:return 0;
    }
}
EMSCRIPTEN_KEEPALIVE const char* web_error() { return lastError.c_str(); }
EMSCRIPTEN_KEEPALIVE const char* web_script_log() {
    if(emu && scriptId>=0 && emu->InternalGetDebugger())
        scriptLog=emu->InternalGetDebugger()->GetScriptManager()->GetScriptLog(scriptId);
    return scriptLog.c_str();
}
}
