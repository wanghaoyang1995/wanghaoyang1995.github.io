# 公共 NES + Lua 引擎

本目录保存固定的 MesenCE 提交、浏览器源码补丁和小型 C++ 桥接。`tools/prepare.py` 从只读 Git 提交导出并应用补丁；`tools/build.py` 使用 Emscripten 7.0.0 生成共享的 `dist/shared/engine/mesen.js`、`mesen.wasm`。

所有游戏使用同一份核心。游戏自己的地址、行为、图片和启动存档都在项目 Lua，不写进公共引擎。当前配置为 NTSC、两个普通 NES 手柄；多分线器、其他外设和区域需单独实现和验证。

桥接负责 ROM/脚本加载、逐帧执行、RGBA、PCM、按键、暂停及只读测试观测。`web_cpu_register(field)` 的 0..7 分别是 PC、A、X、Y、SP、PS、周期低32位和高32位；它不提供更改 CPU 的网页 UI。Lua 仍使用 Mesen 原 API。

源码准备和对象/日志/临时文件均在 `.cache`；原 MesenCE 不修改。GUI/.NET、不需要的主机执行核心和桌面滤镜不参与此构建，必要 Lua 调试后端保留。

## 两个手柄与原始键盘

旧入口继续使用 `web_key(code, down)` 的方向键、Z/X、Enter/Space 到一号手柄映射。双人入口调用 `web_use_explicit_pads(1)` 后，每次逐帧执行前分别调用 `web_set_pad(port, mask)`，`port=0` 是 1P，`port=1` 是 2P。此模式下原始键盘不再直接驱动手柄，Lua 的 `emu.isKeyPressed` 仍可读取 `web_key` 传入的原始键。

| 按钮 | mask 位值 |
| --- | ---: |
| A | 1 |
| B | 2 |
| Select | 4 |
| Start | 8 |
| Up | 16 |
| Down | 32 |
| Left | 64 |
| Right | 128 |

`web_set_pad` 接受 0..255 的完整状态，成功返回 1；非法端口或 mask 返回 0，保留已有状态。默认沿用原生的相反方向互相抵消规则。连发由播放器按仿真帧生成 A/B 脉冲，未增加私有按钮位。

`web_clear_keys()` 同时释放原始键和两个手柄，保留显式模式。重新加载 ROM 也清空输入并保留模式；`web_init()` 回到旧映射模式。`web_use_explicit_pads(0)` 可退出显式模式。切换模式时清空两个手柄状态。

桥接通过原生 `IInputProvider` 写入两端口，顺序为原生按键采集 → 浏览器手柄覆盖 → Lua `inputPolled` 回调 → ROM 读取 `$4016/$4017`。因此脚本在 `inputPolled` 中的 `emu.getInput(0/1)` 能看到网页输入，`emu.setInput` 能继续修改这些状态。

浏览器补丁还修正固定上游提交的 `LuaApi::SetInput` 多余第四个栈槽，仅影响 `MESEN_BROWSER` 构建：保持文档规定的 `emu.setInput(input, port, optionalSubport)`，与 `getInput(port, optionalSubport)` 一致。普通手柄仅有 subport 0；不存在的子端口不会误写物理端口。原 MesenCE 工作树和桌面构建路径保持原样。

底层验证运行 `node tests/browser_inputs.cjs`。测试在真实 WASM 中运行原创 NROM，通过真实 `$4016/$4017` 串行读取验证两口全部八键，并覆盖 Lua 两/三参数调用、子端口、热键隔离、暂停清键、原生重置、ROM 重载及旧映射。精简记录见 `docs/evidence/dual-input-core.json`，完整临时记录在 `.cache/test-results/browser_inputs_evidence.json`。浏览器页面键位和商业游戏双打由各自项目测试验证。

## Lua 内存回调开销

浏览器路径在一次内存操作的回调扫描中复用绝对地址转换结果，实际执行任一 Lua 回调后立即失效并按需重新转换。这样保留注册顺序，也允许前一个回调切换 mapper bank、修改 CPU 寄存器或替换总线值，后一个回调仍看到更新后的状态。只有命中回调时才准备 Lua 上下文与 watchdog；未命中扫描不执行这些准备。

此优化没有缓存 Lua 返回值或 ROM 校验结果，也不改变脚本、模拟时钟和图像接口。只有 `MESEN_BROWSER` 分支采用新路径。`node tests/browser_callbacks.cjs` 用原创 UxROM 在同一次操作中切换两次真实 PRG bank，并验证寄存器可见性与 read/write 替换顺序。商业项目另做了旧/新引擎逐帧等价比较。测量和回归摘要见 `docs/evidence/coop-callback-optimization.json`；诊断中跳过屏幕接口或 memo ROM 信息的临时脚本只用于定位瓶颈，没有进入发布产物。

## Lua 整屏缓冲表批处理

`MESEN_BROWSER` 路径保留 `emu.getScreenBuffer()` / `emu.setScreenBuffer(table)` 的接口，通过 `Lua/lapi.c` 内部 helper 减少每像素调用 Lua C API 的开销。helper 使用固定上游 Lua 5.5.1 的数组值与标签宏，不把其数组误当作旧版 `TValue[]`。桌面构建仍使用原循环，未增加脚本可调用的函数。

读取画面仍先创建全新的普通 Lua 表，再写入 `RGB & 0xFFFFFF` 整数；旧表引用不会被后续读取覆盖，也不复用返回表。视频滤镜和画面尺寸不变。写回固定读取屏幕宽 × 高个槽位，仅整数数组槽走直接读取，其余槽仍逐一执行原来的 `rawgeti` / `tointeger` / `pop`，保留稀疏哈希键、空值、浮点和字符串转换，不调用 `__index` 或 `__len`。

写回在调用时复制数值，保留原 `uint32_t` 截断、`0xFF000000` 异或及 HUD 命令提交顺序；调用后修改 Lua 表不会改变已提交画面。实现使用临时原生数组，不修改 HUD 命令类或所有权。该补丁不包含额外的回调页索引、ROM 哈希缓存、游戏脚本或音频调度改动。

语义回归应与旧核心逐像素比较完整画面，并覆盖 fresh table 与旧引用、稀疏表尾、不同值类型、带元表的表、调用后修改及多次提交顺序。无效非表参数的既有异常路径不属于本次优化范围。
