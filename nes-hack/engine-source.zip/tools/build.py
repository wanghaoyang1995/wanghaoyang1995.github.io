#!/usr/bin/env python3
"""Build the pinned NES + Lua browser core; all intermediates stay in .cache.

Requires Git, Python 3.10+, and an installed/activated emsdk 7.0.0. This command
does not install tools, change the upstream checkout, or assemble the website.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from prepare import ROOT, ENGINE, configuration, prepare_source, sha256

CORE_OUTPUT = ROOT / "dist" / "shared" / "engine"

BASE = ["-O2", "-DMESEN_BROWSER=1", "-fexceptions", "-Wno-deprecated-declarations",
        "-Wno-switch", "-Wno-unused-command-line-argument"]
EXPORTS = ["_web_init", "_web_load_rom", "_web_load_script", "_web_step", "_web_key",
           "_web_use_explicit_pads", "_web_set_pad",
           "_web_clear_keys", "_web_pause", "_web_pixels", "_web_width", "_web_height",
           "_web_audio", "_web_audio_count", "_web_read", "_web_cpu_register", "_web_error", "_web_script_log",
           "_malloc", "_free"]
LINK = ["-O2", "-fexceptions", "--no-entry", "-sMODULARIZE=1", "-sEXPORT_NAME=createMesen",
        "-sENVIRONMENT=web,worker,node", "-sALLOW_MEMORY_GROWTH=1",
        "-sINITIAL_MEMORY=67108864", "-sSTACK_SIZE=4194304", "-sASSERTIONS=1",
        "-sEXPORTED_FUNCTIONS=" + json.dumps(EXPORTS, separators=(",", ":")),
        '-sEXPORTED_RUNTIME_METHODS=["ccall","cwrap","UTF8ToString","FS","HEAPU8","HEAP16"]',
        "-sFORCE_FILESYSTEM=1"]


def translation_units(source: Path) -> list[tuple[str, Path]]:
    omitted = {"HQX", "xBRZ", "KreedSaiEagle", "Scale2x"}
    files = []
    for folder in ("Core/NES", "Core/Shared", "Core/Debugger", "Core/Netplay", "Utilities", "SevenZip"):
        for path in sorted((source / folder).rglob("*")):
            relative = path.relative_to(source)
            if (path.suffix not in (".cpp", ".c") or path.name == "pch.cpp"
                    or any(part in omitted for part in relative.parts)):
                continue
            if (path.name.startswith("ExpressionEvaluator.")
                    and path.name not in ("ExpressionEvaluator.cpp", "ExpressionEvaluator.Nes.cpp")):
                continue
            files.append((relative.as_posix(), path))
    files.extend((p.relative_to(source).as_posix(), p) for p in sorted((source / "Lua").glob("l*.c"))
                 if p.name != "luasocket.c")
    bridge = ENGINE / "browser" / "bridge.cpp"
    if not bridge.is_file():
        raise RuntimeError(f"Browser bridge not found: {bridge}")
    files.append(("browser/bridge.cpp", bridge))
    return files


def run(compiler: Path, arguments: list[str], environment: dict, cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(compiler), *arguments], cwd=cwd, env=environment,
                          capture_output=True, text=True, encoding="utf-8", errors="replace")


def build(args: argparse.Namespace) -> int:
    prepared = prepare_source(args.source)
    source = prepared["source"]
    config = configuration()
    sdk = args.emsdk.resolve()
    emcc = sdk / "upstream" / "emscripten" / "emcc.py"
    empp = emcc.with_name("em++.py")
    em_config = sdk / ".emscripten"
    if not all(path.is_file() for path in (emcc, empp, em_config)):
        raise RuntimeError(f"emsdk is not installed and activated: {sdk}; use --emsdk PATH")

    environment = os.environ.copy()
    environment["EM_CONFIG"] = str(em_config)
    probe = run(emcc, ["--version"], environment, source)
    if probe.returncode:
        raise RuntimeError("Unable to run emcc:\n" + probe.stdout + probe.stderr)
    version_line = probe.stdout.splitlines()[0]
    match = re.search(r"\b(\d+\.\d+\.\d+)\b", version_line)
    expected = config["toolchain"]["version"]
    if not match or match.group(1) != expected:
        raise RuntimeError(f"Expected emsdk {expected}, got {version_line}")

    files = translation_units(source)
    if len(files) != config["expected_translation_units"]:
        raise RuntimeError(f"Expected {config['expected_translation_units']} translation units; found {len(files)}")
    options = BASE + ["-I" + str(source), "-I" + str(source / "Core"), "-I" + str(source / "Utilities")]
    # A changed patch, header, toolchain, or compile flag cannot reuse stale objects.
    identity = {"tree_sha256": prepared["tree_sha256"], "toolchain": version_line,
                "compile_flags": BASE, "translation_units": [name for name, _ in files]}
    key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:20]
    cache = ROOT / ".cache" / "build" / key
    objects, logs, temporary = (cache / name for name in ("objects", "logs", "tmp"))
    for folder in (objects, logs, temporary, CORE_OUTPUT):
        folder.mkdir(parents=True, exist_ok=True)
    for name in ("TMP", "TEMP", "TMPDIR"):
        environment[name] = str(temporary)

    lock = cache / "build.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"Another build owns {lock}; do not remove it while that build runs") from error
    os.write(descriptor, f"{os.getpid()}\n".encode())
    os.close(descriptor)
    started = time.perf_counter()
    try:
        plans = []
        for index, (name, path) in enumerate(files):
            stem = f"{index:03}-{path.stem}-{hashlib.sha256(name.encode()).hexdigest()[:10]}"
            fingerprint = sha256(path)
            obj = objects / (stem + ".o")
            marker = objects / (stem + ".json")
            cached = False
            if obj.is_file() and marker.is_file() and not args.rebuild:
                try:
                    cached = json.loads(marker.read_text(encoding="utf-8")) == {
                        "source_sha256": fingerprint, "object_sha256": sha256(obj)}
                except (OSError, ValueError):
                    pass
            plans.append((name, path, obj, marker, fingerprint, cached, logs / (stem + ".log")))

        if args.link_only and any(not plan[5] for plan in plans):
            raise RuntimeError("--link-only requires current objects; run a normal build first")

        def compile_one(plan: tuple) -> tuple[str, bool, str]:
            name, path, obj, marker, fingerprint, cached, log = plan
            if cached:
                return name, True, "cached"
            compiler = empp if path.suffix == ".cpp" else emcc
            flags = options + (["-std=c++17"] if path.suffix == ".cpp" else [])
            scratch = temporary / (obj.name + ".partial.o")
            result = run(compiler, [*flags, "-c", str(path), "-o", str(scratch)], environment, source)
            output = result.stdout + result.stderr
            log.write_text(output, encoding="utf-8")
            if not result.returncode:
                scratch.replace(obj)
                marker.write_text(json.dumps({"source_sha256": fingerprint,
                                              "object_sha256": sha256(obj)}) + "\n", encoding="utf-8")
            return name, result.returncode == 0, output

        if not args.link_only:
            failed = []
            with ThreadPoolExecutor(max_workers=args.jobs) as pool:
                futures = [pool.submit(compile_one, plan) for plan in plans]
                for index, future in enumerate(as_completed(futures), 1):
                    name, ok, output = future.result()
                    if not ok:
                        failed.append(name)
                        print(f"FAILED {name}\n{output[-5000:]}", flush=True)
                    elif index % 25 == 0 or index == len(plans):
                        print(f"compiled {index}/{len(plans)}", flush=True)
            if failed:
                raise RuntimeError(f"{len(failed)} compilation failure(s); logs: {logs}")

        response = cache / "link.rsp"
        response.write_text("\n".join('"' + str(plan[2]).replace("\\", "/") + '"' for plan in plans)
                            + "\n" + "\n".join(LINK) + "\n", encoding="utf-8")
        print(f"Linking {len(plans)} objects with emsdk {expected}", flush=True)
        result = run(empp, ["@" + str(response), "-o", str(CORE_OUTPUT / "mesen.js")], environment, source)
        (logs / "link.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        outputs = {name: sha256(CORE_OUTPUT / name) for name in ("mesen.js", "mesen.wasm")}
        (cache / "build.json").write_text(json.dumps({**identity, "commit": prepared["commit"],
            "patch_sha256": prepared["patch_sha256"], "outputs": outputs,
            "link_flags": LINK}, indent=2) + "\n", encoding="utf-8")
        print(f"Built dist/shared/engine/mesen.js + mesen.wasm in {time.perf_counter() - started:.1f}s; logs: {logs}")
        return 0
    finally:
        lock.unlink()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT.parent / "MesenCE")
    parser.add_argument("--emsdk", type=Path,
                        default=ROOT.parent / "web_experiments" / "toolchains" / "emsdk")
    parser.add_argument("--jobs", type=int, default=min(8, os.cpu_count() or 1))
    parser.add_argument("--rebuild", action="store_true", help="recompile every object without deleting caches")
    parser.add_argument("--link-only", action="store_true")
    args = parser.parse_args()
    if args.jobs < 1 or (args.rebuild and args.link_only):
        parser.error("--jobs must be positive; --rebuild and --link-only are mutually exclusive")
    try:
        return build(args)
    except (OSError, RuntimeError, ValueError) as error:
        print(f"build: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
