#!/usr/bin/env python3
"""Export the pinned, read-only upstream checkout and apply our browser patch.

Only .cache is written. Existing upstream files and prepared caches are never
edited or recursively deleted. Requires Python 3.10+ and Git.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "shared" / "engine"
SCHEMA = 1


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def configuration() -> dict:
    return json.loads((ENGINE / "upstream.json").read_text(encoding="utf-8"))


def run_git(source: Path, *args: str, **kwargs) -> subprocess.CompletedProcess:
    result = subprocess.run(
        ["git", "--no-optional-locks", "-C", str(source), *args],
        capture_output=True, text=True, encoding="utf-8", errors="replace", **kwargs,
    )
    if result.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed:\n{result.stderr.strip()}")
    return result


def file_manifest(source: Path) -> dict[str, str]:
    return {p.relative_to(source).as_posix(): sha256(p)
            for p in sorted(source.rglob("*")) if p.is_file()}


def export_archive(upstream: Path, commit: str, target: Path) -> None:
    """Extract regular files only; reject links and paths outside target."""
    error_path = target.parent / "archive.log"
    with error_path.open("wb") as errors:
        process = subprocess.Popen(
            ["git", "--no-optional-locks", "-C", str(upstream), "archive", "--format=tar", commit],
            stdout=subprocess.PIPE, stderr=errors,
        )
        try:
            assert process.stdout is not None
            with tarfile.open(fileobj=process.stdout, mode="r|") as archive:
                for member in archive:
                    relative = PurePosixPath(member.name)
                    if relative.is_absolute() or ".." in relative.parts or "\\" in member.name:
                        raise RuntimeError(f"Unsafe archive member: {member.name}")
                    destination = target.joinpath(*relative.parts)
                    if not destination.resolve().is_relative_to(target.resolve()):
                        raise RuntimeError(f"Archive member escapes cache: {member.name}")
                    if member.isdir():
                        destination.mkdir(parents=True, exist_ok=True)
                    elif member.isfile():
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        source = archive.extractfile(member)
                        if source is None:
                            raise RuntimeError(f"Cannot read archive member: {member.name}")
                        with source, destination.open("wb") as output:
                            while chunk := source.read(1024 * 1024):
                                output.write(chunk)
                        if os.name != "nt":
                            destination.chmod(member.mode & 0o777)
                    else:
                        raise RuntimeError(f"Unsupported archive member (link/device): {member.name}")
            if process.wait():
                raise RuntimeError(error_path.read_text(encoding="utf-8", errors="replace"))
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            if process.stdout is not None:
                process.stdout.close()


def prepare_source(upstream: Path | None = None) -> dict:
    upstream = (upstream or ROOT.parent / "MesenCE").resolve()
    config = configuration()
    commit = config["commit"]
    patch = (ENGINE / config["patch"]).resolve()
    if not upstream.is_dir():
        raise RuntimeError(f"Upstream checkout not found: {upstream}; use --source PATH")
    if not patch.is_file():
        raise RuntimeError(f"Browser patch not found: {patch}")
    actual = run_git(upstream, "rev-parse", "--verify", f"{commit}^{{commit}}").stdout.strip()
    if actual != commit:
        raise RuntimeError(f"Expected upstream commit {commit}, found {actual}")

    patch_hash = sha256(patch)
    key = f"mesence-{commit[:12]}-{patch_hash[:16]}"
    cache = ROOT / ".cache" / "prepared"
    cache.mkdir(parents=True, exist_ok=True)
    for container in sorted(cache.glob(key + "-*")):
        marker = container / "prepared.json"
        if not marker.is_file():
            continue
        try:
            metadata = json.loads(marker.read_text(encoding="utf-8"))
            source = container / "source"
            if (metadata.get("schema") == SCHEMA and metadata.get("commit") == commit
                    and metadata.get("patch_sha256") == patch_hash
                    and metadata.get("files") == file_manifest(source)):
                return {**metadata, "source": source, "container": container}
        except (OSError, ValueError):
            continue

    container = Path(tempfile.mkdtemp(prefix=key + "-", dir=cache))
    source = container / "source"
    source.mkdir()
    print(f"Preparing pinned MesenCE {commit} in {source}", file=sys.stderr, flush=True)
    export_archive(upstream, commit, source)
    # Stop repository discovery at .cache: apply to this exported tree, never
    # to either the source checkout or this project's surrounding worktree.
    environment = os.environ.copy()
    environment["GIT_CEILING_DIRECTORIES"] = str((ROOT / ".cache").resolve())
    run_git(source, "apply", "--check", str(patch), env=environment)
    run_git(source, "apply", str(patch), env=environment)
    files = file_manifest(source)
    tree_hash = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    metadata = {"schema": SCHEMA, "commit": commit, "patch_sha256": patch_hash,
                "tree_sha256": tree_hash, "files": files}
    (container / "prepared.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8",
    )
    return {**metadata, "source": source, "container": container}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT.parent / "MesenCE",
                        help="read-only upstream Git checkout (default: ../MesenCE)")
    args = parser.parse_args()
    try:
        prepared = prepare_source(args.source)
        print(prepared["source"])
        return 0
    except (OSError, RuntimeError, tarfile.TarError) as error:
        print(f"prepare: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
